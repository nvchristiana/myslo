<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbQRMemory";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM videos WHERE id = $id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lihat Video Kenangan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #fbc2eb, #a6c1ee);
            padding: 40px;
            text-align: center;
        }
        .container {
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            display: inline-block;
        }
        video {
            margin-top: 20px;
            border-radius: 10px;
            width: 100%;
            max-width: 700px;
        }
    </style>
</head>
<body>
<div class="container">
<?php
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h2>" . htmlspecialchars($row['title']) . "</h2>";
    echo "<p>" . nl2br(htmlspecialchars($row['description'])) . "</p>";
    echo "<video controls>
            <source src='" . htmlspecialchars($row['video_path']) . "' type='video/mp4'>
            Browser Anda tidak mendukung pemutaran video.
          </video>";
} else {
    echo "<p>Video tidak ditemukan.</p>";
}
$conn->close();
?>
</div>
</body>
</html>
