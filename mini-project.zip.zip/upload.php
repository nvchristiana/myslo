<?php
// Tampilkan semua error untuk debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "dbQRMemory";
$port = 3307; // port XAMPP kamu

$conn = new mysqli($host, $user, $pass, $dbname, $port);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Cek apakah form dikirim dan file ada
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['video'])) {

    $title = $_POST['title'];
    $description = $_POST['description'];
    $videoName = $_FILES['video']['name'];
    $videoTmp = $_FILES['video']['tmp_name'];
    $videoError = $_FILES['video']['error'];

    if ($videoError !== UPLOAD_ERR_OK) {
        die("Terjadi kesalahan saat mengunggah file. Kode error: $videoError");
    }

    // Folder upload
    $uploadDir = "uploads/";
    $qrDir = "qr/";
    if (!is_dir($uploadDir)) mkdir($uploadDir);
    if (!is_dir($qrDir)) mkdir($qrDir);

    $videoPath = $uploadDir . uniqid() . "_" . basename($videoName);

    // Pindahkan file
    if (!move_uploaded_file($videoTmp, $videoPath)) {
        die("Gagal memindahkan file video.");
    }

    // Simpan ke database (tanpa QR dulu)
    $stmt = $conn->prepare("INSERT INTO videos (title, description, video_path) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $description, $videoPath);
    $stmt->execute();
    $videoId = $stmt->insert_id;
    $stmt->close();

    // Gunakan IP lokal agar bisa diakses dari HP
    $ip = $_SERVER['SERVER_ADDR'];
    $videoUrl = "http://$ip/mini-project/view.php?id=" . $videoId;

    // Buat QR code
    include "phpqrcode/qrlib.php";
    $qrFile = $qrDir . "qr_" . $videoId . ".png";
    QRcode::png($videoUrl, $qrFile);

    // Update DB
    $stmt = $conn->prepare("UPDATE videos SET qr_code_path = ? WHERE id = ?");
    $stmt->bind_param("si", $qrFile, $videoId);
    $stmt->execute();
    $stmt->close();
    ?>

    <!DOCTYPE html>
    <html>
    <head>
        <title>Upload Result</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg,rgb(113, 149, 248),rgb(243, 141, 141));
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }
            .result-container {
                background-color: white;
                padding: 30px 40px;
                border-radius: 15px;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
                width: 400px;
                text-align: center;
            }
            img {
                margin-top: 15px;
            }
            a {
                display: inline-block;
                margin-top: 20px;
                color:rgb(250, 109, 125);
                text-decoration: none;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="result-container">
            <h2>Upload Successful!</h2>
            <p><strong>Title:</strong> <?= htmlspecialchars($title) ?></p>
            <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($description)) ?></p>
            <p><strong>QR Code:</strong></p>
            <img src="<?= $qrFile ?>" alt="QR Code">
            <br>
            <a href="index.php">Upload Another</a>
        </div>
    </body>
    </html>

    <?php
} else {
    echo "Tidak ada file yang diunggah.";
}

$conn->close();
?>
