Myslo QR Video App

A PHP-based web app that allows users to upload memory videos and receive a unique QR code to access each video later.

Features:
- Upload personal videos with a title and description
- Automatically generates a QR code linked to each video
- Simple and responsive web interface
- Uses PHP, MySQL, and QRCode library (phpqrcode)

How to Run:
1. Place the project folder into your xampp/htdocs directory
2. Create a database named dbQRMemory and import the table "videos"
3. Make sure your Apache and MySQL are running (via XAMPP)
4. Open your browser and go to: http://localhost/mini-project

Folder Structure:
- index.php — upload form page
- upload.php — handles upload and QR generation
- view.php — shows the video based on scanned QR
- uploads/ — (empty) folder for uploaded videos
- qr/ — (empty) folder for generated QR codes
- phpqrcode/ — QR code generator library
- logo.png — project branding icon (mouse & monkey)
