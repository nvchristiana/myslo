<!DOCTYPE html>
<html>
<head>
    <title>Upload Memory Video - QR Memory</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg,rgb(117, 147, 243), #ffe8d3);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .upload-container {
            background-color: white;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            width: 400px;
            text-align: center;
        }

        .logo {
            width: 100px;
            margin-bottom: 15px;
        }

        h2 {
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            color: #555;
            text-align: left;
        }

        input[type="text"],
        textarea,
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            margin-top: 20px;
            width: 100%;
            background-color:rgb(247, 53, 75);
            color: white;
            border: none;
            padding: 10px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color:rgb(108, 198, 240);
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <!-- Gambar logo Myslo -->
        <img src="logo.png" class="logo" alt="Myslo">
        <h2>Upload Your Memory Video</h2>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <label>Video Title:</label>
            <input type="text" name="title" required>

            <label>Description:</label>
            <textarea name="description" rows="4" required></textarea>

            <label>Select Video File:</label>
            <input type="file" name="video" accept="video/*" required>

            <input type="submit" value="Upload">
        </form>
    </div>
</body>
</html>
